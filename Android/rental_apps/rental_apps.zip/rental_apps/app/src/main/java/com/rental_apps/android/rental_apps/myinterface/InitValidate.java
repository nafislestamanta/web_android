package com.rental_apps.android.rental_apps.myinterface;

import android.widget.EditText;

/**
 * Created by Ujang Wahyu on 04/01/2018.
 */
public interface InitValidate {
    public boolean cek(EditText et);
}
