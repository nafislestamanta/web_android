package com.rental_apps.android.rental_apps.helper;

/**
 * Created by Ujang Wahyu on 04/01/2018.
 */

public class SweetAlert {

}
